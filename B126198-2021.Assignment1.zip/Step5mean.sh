#!/usr/bin/bash

# This script is incomplete, please do not execute this script

# This script is used to generate plain txt tab-delimited output files that calculates average counts per gene for each group

# sort the sample detail file to get group replicate information
grep -v "ID" /localdisk/data/BPSM/AY21/fastq/100k.fqfiles | sort -k2,2 -k4,5 > ./outputfiles/sorttest.list

# produce an id file with their filename "$1" and "clone,time,treament" as group id 
grep -v "ID" /localdisk/data/BPSM/AY21/fastq/100k.fqfiles | sort -k2,2 -k4,5 | awk  '{print $1, $2, $4, $5;}'>groupid.txt
# contain only filename 
grep -v "ID" /localdisk/data/BPSM/AY21/fastq/100k.fqfiles | sort -k2,2 -k4,5 | awk  '{print $1;}'>groupid_individual.txt
# extract gene infomation txt for further file combination
cat ./bedfiles/TriTrypDB-46_TcongolenseIL3000_2019.bed | awk 'BEGIN{FS="\t"}{print $5}'>./outputfiles/geneinfo.txt

# The following idea is to generate a data file with different columns (from different count list file) based on the sorted filename list above

# make short count list files and paste each counts per gene for every list into "allcount.list"
while read myfilename; 
do 
cut -f 6 ./countreadfiles/100k.${myfilename}.list> ./countreadfiles/short.${myfilename}.list
done <./groupid_individual.txt
paste ./outputfiles/geneinfo.txt ./countreadfiles/short.* >./countreadfiles/allcount.list
# every three columns are three replicates from one group with same group id "clone.time.treatment"

# then we can use loops to sum and calculate the average mean count per gene for each group

cat ./countreadfiles/allcount.list | awk '{for(i=1;i<=(NF-1)/3; i++){printf ("%s",($(3*i-1)+$(3*i)+$(3*i+1))/3)}}'>./countreadfiles/averagecount.list


# geneinfo can be added in this file using "sed" as well

