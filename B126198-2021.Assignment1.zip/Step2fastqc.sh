#!/usr/bin/bash

# This script is used to assess the number and quality of the raw sequence data based on the outout of Step1fastqc script

# Make a new dir for saving output information file
mkdir ./outputfiles
 
# Access the sample details file to get the totol number of raw sequence data
num_raw_seq=$(grep -v "ID" /localdisk/data/BPSM/AY21/fastq/100k.fqfiles | wc -l)

echo -e "\nIn the provided sample details file, there are total $num_raw_seq sample groups with different conditions"


# Save the fastqc report zip file names and locations into a list file
cd ./fastqc_report/
ls -1 *.zip >./fastqc_report.list
cd ..
sed -n 's/\(.\)\{4\}$//w ./outputfiles/fastqc_report_loc.list' ./fastqc_report/fastqc_report.list


# Count the number of fastqc report zip files
num_report=$(cat ./outputfiles/fastqc_report_loc.list | wc -l)

echo -e "\nThe names of fastqc report zip files have been included in the fastqc_report_loc.list file under a new dir named outputfiles"

echo -e "\nThe total number of fastqc report zip files is $num_report"

# Use unzip to collect quality-related information of the raw sequence data
echo -e "\nUnzipping zip files to collect bad quality information..."
cd ./fastqc_report/
unzip -o -q '*.zip'
cd ..

while read myfilelocate
do
grep -v "PASS" ./fastqc_report/$myfilelocate/summary.txt>>./outputfiles/badqualityrecord.list
done < ./outputfiles/fastqc_report_loc.list

echo -e "\nBad quality information has been collected into badqualityrecord.list under the new dir named outputfiles"

echo -e "\nIt is recommended to check this bad quality file to assess the quality of the raw RNAseq data"

