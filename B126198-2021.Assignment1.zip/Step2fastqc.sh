#!/usr/bin/bash

# This script is used to assess the number and quality of the raw sequence data based on the outout of Step1fastqc script

# Access the sample details file to get the totol number of raw sequence data
num_raw_seq=$(grep -v "ID" /localdisk/data/BPSM/AY21/fastq/100k.fqfiles | wc -l)

echo -e "\nIn the provided sample details file, there are total $num_raw_seq sample groups with different conditions"


# Save the fastqc report html file names into a list file
ls -1 ./fastqc_report/*.html >./fastqc_report.list

# Count the number of fastqc report html files
num_report=$(cat ./fastqc_report.list | wc -l)

echo -e "\nThe names of fastqc report html files have been included in the fastqc_report.list file under the current dir"

echo -e "\nThe total number of fastqc report html files is $num_report"

# Assess the quality of the raw sequence data

