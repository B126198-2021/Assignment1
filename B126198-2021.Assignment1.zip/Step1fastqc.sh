#!/usr/bin/bash

# This program is used to perform a quality check of RNA-seq data analysis by FastQC.

# Make a output dir for saving files
mkdir ./fastqc_report

# Use the installed programme fastqc to produce fastqc reports of all fastqc files from the localdisk
fastqc -t 6 -o ./fastqc_report /localdisk/data/BPSM/AY21/fastq/*.fq.gz
