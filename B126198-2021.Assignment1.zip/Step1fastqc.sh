#!/usr/bin/bash

# This program is used to perform a quality check of RNA-seq data analysis by FastQC.

# Make a output dir for saving files
mkdir ./fastqc_report

# Use the installed programme fastqc to produce fastqc reports of all fastqc files from the localdisk

echo -e "\nThis script is going to process all the RNAseq data stored in the given file location\nPlease wait for a success message"

fastqc -q -t 6 -o ./fastqc_report /localdisk/data/BPSM/AY21/fastq/*.fq.gz

echo -e "\nsuccess: The fastqc programme has generated all the fastqc reports of the raw data which are stored in a new dir ./fastqc_report"

