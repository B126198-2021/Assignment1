#/usr/bin/bash

# This script is incomplete, please do not execute it

# This script is used for generate "fold change" data for the "group-wise" comparisons

# as we should make a data file containing the average count per gene for each group in step 5
# we can use "awk" to select different groups based on group id "clone.time.treatment"

# use log-2 gene exporession fold change
