#!/usr/bin/bash

# Step 3-1  align the read pairs to Trypanosoma congolense genome using hisat2

# Make reference genome files
cp -r /localdisk/data/BPSM/AY21/Tcongo_genome/ .
cd ./Tcongo_genome/
gunzip TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz
echo -e "\nMaking reference Tgenome files for alignment process..."
hisat2-build --quiet -p 6 TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta Tgenome
echo -e "\nReference Tgeneome files have been prepared"
cd ..

# Alignment process
sed -n 's/\(.\)\{9\}$//w ./outputfiles/fastqc_name.list' ./outputfiles/fastqc_report_loc.list
sort ./outputfiles/fastqc_name.list | uniq -d>./outputfiles/fastqc_name_paired.list

echo -e "\nAligning all paired fq.gz files from sample groups\nPlease wait for a success information"

mkdir ./samfiles
while read myfilename
do
hisat2 --quiet -t -p 6 -x Tcongo_genome/Tgenome -1 /localdisk/data/BPSM/AY21/fastq/${myfilename}_1.fq.gz -2 /localdisk/data/BPSM/AY21/fastq/${myfilename}_2.fq.gz -S ./samfiles/${myfilename}.sam
done <./outputfiles/fastqc_name_paired.list

echo -e "\nsuccess: Alignment process done by hisat2 programme and .sam files have been generated and stored in a new dir ./samfiles"

# Step 3-2 convert the "sam" files into "bam" format using samtools

mkdir ./bamfiles
echo -e "\nConverting .sam files into .bam files using samtools view,sort, and index tools...\nPlease wait for a success information"
while read myfilename
do
samtools view -@ 6 -S ./samfiles/${myfilename}.sam -1b -o ./bamfiles/${myfilename}.bam
samtools sort -@ 6 ./bamfiles/${myfilename}.bam -o ./bamfiles/${myfilename}.sort.bam
samtools index -@ 6 ./bamfiles/${myfilename}.sort.bam
done <./outputfiles/fastqc_name_paired.list

echo -e "\nsuccess: Converted the output to indexed "bam" format with samtools and bam files are stored in a new dir ./bamfiles"



