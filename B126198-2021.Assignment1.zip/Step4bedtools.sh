#!/usr/bin/bash

# This step 4 script is used to generate counts data using bedtools programme

# Extra an available bedfile for bedtools
mkdir ./bedfiles
cp /localdisk/data/BPSM/AY21/TriTrypDB-46_TcongolenseIL3000_2019.bed ./bedfiles/

# Multicov to generate counts data files for every bam file
mkdir ./countreadfiles

echo -e "\nUsing bedtools to generate count data...\nPlease wait for a success information"

while read myfilename
do
bedtools multicov -bams ./bamfiles/${myfilename}.sort.bam -bed ./bedfiles/TriTrypDB-46_TcongolenseIL3000_2019.bed > ./countreadfiles/${myfilename}.list
done <./outputfiles/fastqc_name_paired.list

bedtools multicov -bams ./bamfiles/*.sort.bam -bed ./bedfiles/TriTrypDB-46_TcongolenseIL3000_2019.bed > ./countreadfiles/allcountread.list

echo -e "\nsuccess: Counts data files have been generated and stored under a new  dir named countreadfiles"



