#!/usr/bin/bash

# This step 4 script is used to generate counts data using bedtools programme

# Extra an available bedfile for bedtools
mkdir ./bedfiles
cp /localdisk/data/BPSM/AY21/TriTrypDB-46_TcongolenseIL3000_2019.bed ./bedfiles/

# Multicov to generate counts data from multiple groups
echo -e "\nUsing bedtools to generate counts data...\nPlease wait for a success information"
bedtools multicov -bams ./bamfiles/*.sort.bam -bed ./bedfiles/TriTrypDB-46_TcongolenseIL3000_2019.bed > ./outputfiles/countreads.list
echo -e "\nsuccess: Counts data file has been generated under an existing dir named outputfiles"



